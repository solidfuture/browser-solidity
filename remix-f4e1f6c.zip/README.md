# Automatic build
Built website from `f4e1f6c`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-f4e1f6c.zip`.
